
var app = angular.module("loginApp", ["ngRoute"]);

//config function for making SPA
/*app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "",
        controller  : ""
    }); 

});*/